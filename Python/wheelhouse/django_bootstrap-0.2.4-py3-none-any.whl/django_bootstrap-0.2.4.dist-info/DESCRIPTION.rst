Django class-based views ready to work with Twitter's Bootstrap toolkit, designed to kickstart development of webapps and sites.


