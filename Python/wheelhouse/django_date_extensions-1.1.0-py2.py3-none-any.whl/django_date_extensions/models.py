# Require to run the tests using `./manage.py test ...`
